#include <stdio.h>

int main()
{ 
  int P,CH;
  float R,T,SI;
  printf("P:");
  scanf("%d",&P);
  printf("R:");
  scanf("%f",&R);
  printf("Choose Time\n1.year\n2.month");
  scanf("%d",&CH);
  if (CH==1)
  {
     printf("enter time(years):");
     scanf("%f",&T);
  }
  else if (CH==2)
  {
    printf("enter time(months):");
    scanf("%f",&T);
    T=T/12;
  }
   SI=(P*R*T)/100;
   printf("SI:%F",SI);
 }
